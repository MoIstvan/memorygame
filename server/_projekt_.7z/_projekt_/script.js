const delay = 5000; // ms? | 5000 - ((diff-1)*1000)
let diff = 1; // 1 ~ 3
let count;

const slider = document.getElementById("slider");
const span = document.getElementById("szoveg");
const start = document.getElementById("start");
slider.addEventListener("mouseup", ttype);
start.addEventListener("click", diff_set);

const cards = [];

function ttype(_)
{
    if(slider.value == 1) span.innerText = "Könnyű";
    if(slider.value == 2) span.innerText = "Közepes";
    if(slider.value == 3) span.innerText = "Nehéz";
    diff = slider.value;
}

function diff_set(_)
{
    count = 5 + (slider.value * 5);
    startGame();
}

function startGame()
{
    for (let i = 0; i < count / 2; i++)
    {
        const div = document.createElement("div");
        const img = document.createElement("img");
        img.src = `https://picsum.photos/seed/${Math.random() * 1000000}/200/300`;
        div.classList.add(`img${i}`);
        div.appendChild(img);
        cards.push(div,div);
    }
    shuffle(cards);
    show();
}

function shuffle(a)
{
    for (let i = a.length - 1; i > 0; i--)
    {
        let j = Math.floor(Math.random() * (i+1));
        [a[i], a[j]] = [a[j], a[i]];
    }
}

function show()
{
    const c = document.querySelector(".container");
    for (let i = 0; i < cards.length; i++) {
        c.innerHTML += cards[i].outerHTML;
    }
}